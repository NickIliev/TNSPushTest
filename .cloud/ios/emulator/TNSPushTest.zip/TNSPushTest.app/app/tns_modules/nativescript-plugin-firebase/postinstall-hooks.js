require('nativescript-hook')(__dirname).postinstall();
