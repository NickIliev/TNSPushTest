require('nativescript-hook')(__dirname).preuninstall();
