Object.defineProperty(exports, "__esModule", { value: true });
exports.DIALOG_FRAGMENT_TAG = "dialog";
//# sourceMappingURL=constants.js.map