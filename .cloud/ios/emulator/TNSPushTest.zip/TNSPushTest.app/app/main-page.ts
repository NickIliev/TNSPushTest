import { EventData } from 'data/observable';
import { Page } from 'ui/page';
import { HelloWorldModel } from './main-view-model';
import * as firebase from "nativescript-plugin-firebase";
// Event handler for Page "navigatingTo" event attached in main-page.xml
export function navigatingTo(args: EventData) {
    console.log("navigatingTo");
    let page = <Page>args.object;
    page.bindingContext = new HelloWorldModel();

    firebase.init({
        
        onMessageReceivedCallback: (message: firebase.Message) => {
            console.log("onMessageReceivedCallback");

            console.log(`Title: ${message.title}`);
            console.log(`Body: ${message.body}`);
            // if your server passed a custom property called 'foo', then do this:
            console.log(`Value of 'foo': ${message.data.foo}`);
        },

        onPushTokenReceivedCallback: (token: any) => {
            console.log("onPushTokenReceivedCallback");

            console.log("Firebase push token: " + token);
        }
    }).then(() => {
        console.log("firebase init");
    })
}