"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var main_view_model_1 = require("./main-view-model");
var firebase = require("nativescript-plugin-firebase");
// Event handler for Page "navigatingTo" event attached in main-page.xml
function navigatingTo(args) {
    console.log("navigatingTo");
    var page = args.object;
    page.bindingContext = new main_view_model_1.HelloWorldModel();
    firebase.init({
        onMessageReceivedCallback: function (message) {
            console.log("onMessageReceivedCallback");
            console.log("Title: " + message.title);
            console.log("Body: " + message.body);
            // if your server passed a custom property called 'foo', then do this:
            console.log("Value of 'foo': " + message.data.foo);
        },
        onPushTokenReceivedCallback: function (token) {
            console.log("onPushTokenReceivedCallback");
            console.log("Firebase push token: " + token);
        }
    }).then(function () {
        console.log("firebase init");
    });
}
exports.navigatingTo = navigatingTo;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi1wYWdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWFpbi1wYWdlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEscURBQW9EO0FBQ3BELHVEQUF5RDtBQUN6RCx3RUFBd0U7QUFDeEUsc0JBQTZCLElBQWU7SUFDeEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUM1QixJQUFJLElBQUksR0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQzdCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxpQ0FBZSxFQUFFLENBQUM7SUFFNUMsUUFBUSxDQUFDLElBQUksQ0FBQztRQUVWLHlCQUF5QixFQUFFLFVBQUMsT0FBeUI7WUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1lBRXpDLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBVSxPQUFPLENBQUMsS0FBTyxDQUFDLENBQUM7WUFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFTLE9BQU8sQ0FBQyxJQUFNLENBQUMsQ0FBQztZQUNyQyxzRUFBc0U7WUFDdEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBbUIsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFLLENBQUMsQ0FBQztRQUN2RCxDQUFDO1FBRUQsMkJBQTJCLEVBQUUsVUFBQyxLQUFVO1lBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztZQUUzQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxDQUFDO1FBQ2pELENBQUM7S0FDSixDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ0osT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNqQyxDQUFDLENBQUMsQ0FBQTtBQUNOLENBQUM7QUF4QkQsb0NBd0JDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRXZlbnREYXRhIH0gZnJvbSAnZGF0YS9vYnNlcnZhYmxlJztcbmltcG9ydCB7IFBhZ2UgfSBmcm9tICd1aS9wYWdlJztcbmltcG9ydCB7IEhlbGxvV29ybGRNb2RlbCB9IGZyb20gJy4vbWFpbi12aWV3LW1vZGVsJztcbmltcG9ydCAqIGFzIGZpcmViYXNlIGZyb20gXCJuYXRpdmVzY3JpcHQtcGx1Z2luLWZpcmViYXNlXCI7XG4vLyBFdmVudCBoYW5kbGVyIGZvciBQYWdlIFwibmF2aWdhdGluZ1RvXCIgZXZlbnQgYXR0YWNoZWQgaW4gbWFpbi1wYWdlLnhtbFxuZXhwb3J0IGZ1bmN0aW9uIG5hdmlnYXRpbmdUbyhhcmdzOiBFdmVudERhdGEpIHtcbiAgICBjb25zb2xlLmxvZyhcIm5hdmlnYXRpbmdUb1wiKTtcbiAgICBsZXQgcGFnZSA9IDxQYWdlPmFyZ3Mub2JqZWN0O1xuICAgIHBhZ2UuYmluZGluZ0NvbnRleHQgPSBuZXcgSGVsbG9Xb3JsZE1vZGVsKCk7XG5cbiAgICBmaXJlYmFzZS5pbml0KHtcbiAgICAgICAgXG4gICAgICAgIG9uTWVzc2FnZVJlY2VpdmVkQ2FsbGJhY2s6IChtZXNzYWdlOiBmaXJlYmFzZS5NZXNzYWdlKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIm9uTWVzc2FnZVJlY2VpdmVkQ2FsbGJhY2tcIik7XG5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBUaXRsZTogJHttZXNzYWdlLnRpdGxlfWApO1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEJvZHk6ICR7bWVzc2FnZS5ib2R5fWApO1xuICAgICAgICAgICAgLy8gaWYgeW91ciBzZXJ2ZXIgcGFzc2VkIGEgY3VzdG9tIHByb3BlcnR5IGNhbGxlZCAnZm9vJywgdGhlbiBkbyB0aGlzOlxuICAgICAgICAgICAgY29uc29sZS5sb2coYFZhbHVlIG9mICdmb28nOiAke21lc3NhZ2UuZGF0YS5mb299YCk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgb25QdXNoVG9rZW5SZWNlaXZlZENhbGxiYWNrOiAodG9rZW46IGFueSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJvblB1c2hUb2tlblJlY2VpdmVkQ2FsbGJhY2tcIik7XG5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmlyZWJhc2UgcHVzaCB0b2tlbjogXCIgKyB0b2tlbik7XG4gICAgICAgIH1cbiAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coXCJmaXJlYmFzZSBpbml0XCIpO1xuICAgIH0pXG59Il19